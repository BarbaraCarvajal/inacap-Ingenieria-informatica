



kilometros = 12.25
millas = 7.38
millas_a_kilometros = millas * 1.61
kilometros_a_millas = kilometros / 1.61
print(millas, " millas son ", round(millas_a_kilometros, 2), " kilómetros ")
print(kilometros, " kilómetros son ", round(kilometros_a_millas, 2), " millas ")