


print("Python es un lenguaje interpretado")
print()
print()
print("Para programar en Python,\nnecesitarás el intérprete Python")

print("Python", "es", "un", "lenguaje", "interpretado", sep="-")

print("Python","es","un", sep="_", end="*")
print("lenguaje","interpretado.",sep="*", end="\n")

print("Fundamentos","Programacion","en",sep="***",end="...")
print("Python")

print("Estoy \naprendiendo \nPython")

#print("    *\n* "*2"\n*"*2)
