

# ingresa un valor flotante para la variable a aquí # ingresa un valor flotante para la variable b aquí
# muestra el resultado de la suma aquí
# muestra el resultado de la resta aquí
# muestra el resultado de la multiplicación aquí # muestra el resultado de la división aquí


num1 = float(input("Ingrese el primer numero:  "))
num2 = float(input("Ingrese el segundo numero:  "))

print("El resultado de la suma entre {} y {} es: {}".format(num1,num2,int(num1+num2)))
print("El resultado de la resta entre {} y {} es: {}".format(num1,num2,int(num1-num2)))
print("El resultado de la multiplicacion entre {} y {} es: {}".format(num1,num2,int(num1*num2)))
print("El resultado de la division entre {} y {} es: {}".format(num1,num2,(num1/num2)))

