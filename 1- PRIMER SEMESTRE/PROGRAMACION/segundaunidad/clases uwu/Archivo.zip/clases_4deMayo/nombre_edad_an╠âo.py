


nombre = input("Ingrese su nombre \n")
año = int(input("Ingrese su año de nacimiento \n"))
print("Su nombre es {} y su edad aproximada es {}".format(nombre,2022-año))

