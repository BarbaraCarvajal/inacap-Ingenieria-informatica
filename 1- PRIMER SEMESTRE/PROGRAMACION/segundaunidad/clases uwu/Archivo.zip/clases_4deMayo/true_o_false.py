

#verdadero o falso sin if, ejercicio tipo prueba!!

num =int(input("Ingrese un numero \n"))
print(num>=100)

num =int(input("Ingrese un numero \n"))
print(num>5 and num<10) 

num =int(input("Ingrese un numero \n"))
print(not(num>5 and num<10))




