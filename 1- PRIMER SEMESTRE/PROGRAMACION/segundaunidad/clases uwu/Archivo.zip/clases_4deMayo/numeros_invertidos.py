

"""
num = int(input("ingrese un numero \n"))

unidad = num%10
decena = num//10

print(str(unidad)+str(decena))

"""
num = int(input("ingrese un numero \n"))

unidad = num%10
print(unidad)
print("+")
decena = num//10
print(decena)
print("=")
print(unidad + decena)



