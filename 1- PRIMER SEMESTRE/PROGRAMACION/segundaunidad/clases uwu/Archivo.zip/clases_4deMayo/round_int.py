
print(round(3.9))
print(int(-3.9))

