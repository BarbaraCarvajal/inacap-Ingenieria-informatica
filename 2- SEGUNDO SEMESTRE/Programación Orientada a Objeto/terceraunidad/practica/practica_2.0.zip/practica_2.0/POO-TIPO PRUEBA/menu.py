def Menu():
    print("1: Listar Alumno")
    print("2: Agregar Alumno")
    print("3: Modificar Alumno")
    print("4: Eliminar Alumno")
    print("5: Buscar Alumno")
    print("6: Salir")
    opc=int(input("Ingrese su opcion: "))
    return opc